﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityManagementSystem
{
    class Departments
    {
        public string Departmentname { get; set; }
        Course[] listOfcourses;
        public int totalcourse { get; set; }
        public Section Section { get; set; }
        TeachingHour[] teachingHrs;
        public int CreditCount { get; set; }
        public Departments()
        {
            listOfcourses = new Course[100];
            teachingHrs = new TeachingHour[1000];
        }
        public Departments(string name)
        {
            Departmentname = name;
            listOfcourses = new Course[100];
            teachingHrs = new TeachingHour[1000];


        }
        public void ShowInfo()
        {
            Console.WriteLine(" DEPARTMENT NAME IS: " + Departmentname);
            Console.WriteLine("TOTAL COURSE NO IS: " + totalcourse);
        }
        public void AddCourse(params Course[] courses)
        {
            foreach (var course in courses)
            {
                if (totalcourse < 100)
                    listOfcourses[totalcourse++] = course;
            }
        }
        public void RemoveCourse(Course course)
        {
            for (int i = 0; i < totalcourse; i++)
            {
                if (course.CorID.Equals(listOfcourses[i].CorId))
                {
                    for (int j = i; j < totalcourse - 1; j++)
                    {
                        listOfcourses[j] = listOfcourses[j + 1];
                    }
                    totalcourse--;
                    break;
                }

            }
        }
        public void AddNewCourseNumber(Course cor, int num)
        {
            cor.AddCorNum(num);
        }
        public Course SearchCourse(string id)
        {
            Course b = null;
            for (int i = 0; i < totalcourse; i++)
            {
                if (listOfcourses[i].CorId.Equals(id))
                {
                    b = listOfcourses[i];
                    break;
                }
            }
            return b;
        }
        public void ShowAllCourses()
        {
            for (int i = 0; i < totalcourse; i++)
            {
                listOfcourses[i].ShowInfo();
            }
        }
        public void AddTeachingHours(TeachingHour teachingHr)
        {
            teachingHrs[CreditCount++] = teachingHr;
        }
        public void ShowAllCredits()
        {

            for (int i = 0; i < CreditCount; i++)
            {
                Console.WriteLine("DEPARTMENT :);
                teachingHrs[i].Departments.ShowInfo();
                Console.WriteLine("TEACHING HOURS :");
                teachingHrs[i].ShowInfo();
                Console.WriteLine();
            }

        }


    }
}
